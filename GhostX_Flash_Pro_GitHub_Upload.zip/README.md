# GhostX_Flash_Pro (2025 Comprehensive Edition) ⚡📱

**GhostX_Flash_Pro** is a unified, multi-platform flashing and mobile repair tool designed for the 2025 ecosystem. It integrates several industry-standard protocols and chipset-specific tools into a single, cohesive interface (GUI & CLI).

---

## 🌟 Key Features

*   **Multi-Chipset Flashing**:
    *   **MTK (MediaTek)**: Integrated support via `mtkclient` for Read/Write/Unlock operations.
    *   **Unisoc (SPD)**: Support for `.pac` files utilizing leaked factory keys.
    *   **Qualcomm**: EDL mode flashing for XML-based ROMs.
*   **FRP Bypass (Factory Reset Protection)**: Automated ADB-based removal of account locks for modern Android versions.
*   **Firmware Downloader**: Intelligent stub-based downloader for Samsung (Samloader), Xiaomi, and Google Pixel.
*   **Ghost Browser**: A headless Selenium-powered browser for automated web-based flashing tasks and screenshot captures.
*   **2025 GUI**: A modern, easy-to-use Tkinter interface for one-click operations.
*   **Standalone Executable**: Built with PyInstaller for portability across Linux, macOS, and Termux/Android.

---

## 🛠️ Requirements

*   **Python 3.x** (for source execution)
*   **ADB & Fastboot** (must be in system PATH)
*   **Selenium & BeautifulSoup4** (for browser automation)
*   **Tkinter** (for GUI mode)

---

## 🚀 Quick Start

### Installation

Clone the repository and install dependencies:

```bash
git clone https://github.com/your-username/GhostX_Flash_Pro.git
cd GhostX_Flash_Pro
pip install -r requirements.txt
```

### Usage

#### Launch GUI Mode
```bash
python3 GhostflashPro.py --gui
```

#### CLI Flashing (MTK)
```bash
python3 GhostflashPro.py --flash mtk --file /path/to/scatter.txt
```

#### Automated FRP Bypass
```bash
python3 GhostflashPro.py --frp
```

---

## 📂 Project Structure

*   `GhostflashPro.py`: Main entry point and core logic.
*   `asl/`: (Optional Integration) AI-Assisted Security Lab components.
*   `dist/`: Contains the standalone compiled executable.
*   `README.md`: Project documentation.
*   `LICENSE`: MIT License information.

---

## ⚠️ Disclaimer

**Educational Purposes Only.** Flashing firmware can permanently brick your device. The authors are not responsible for any data loss or hardware damage. Always backup your data before proceeding.

---
*Created by the GhostX Team (2025).*
